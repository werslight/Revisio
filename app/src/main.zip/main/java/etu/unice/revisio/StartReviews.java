package etu.unice.revisio;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class StartReviews extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_begin_studies);


    }
}
