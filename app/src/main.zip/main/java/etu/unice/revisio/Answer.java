package etu.unice.revisio;

public class Answer {
    private String answer;
    private boolean value;

    public Answer(String name, boolean value) {
        this.answer = answer;
        this.value = value;
    }
}