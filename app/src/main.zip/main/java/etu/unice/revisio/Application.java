package etu.unice.revisio;

public class Application {
    public static final String CATEGORY = "category";
    public static final String FILES = "files";
    public static final String RESULT = "result";
}
